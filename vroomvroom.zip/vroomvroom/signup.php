<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>Vroom Vroom</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
        <!--
CSS
============================================= -->
        <link rel="stylesheet" href="css/linearicons.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/nice-select.css">							
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">			
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>	
        <?php

        include 'header.php';
        ?>


        <!-- start banner Area -->
        <section class="banner-area relative about-banner" id="home">	
            <div class="overlay overlay-bg"></div>
            <div class="container">				
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            Sign Up				
                        </h1>	
                        <p class="text-white link-nav"><a href="index.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="about.php">Sign Up</a></p>
                    </div>	
                </div>
            </div>
        </section>
        <!-- End banner Area -->	



        <?php
		//connect to database
        $conn=mysqli_connect("localhost", "root", "", "vroomvroom");
        if($conn->connect_error){
            die("Connection failed:". $conn-> connect_error);
        }

        if(isset($_POST["submit"])){
			//define variables
            $FullName=$_POST['FullName'];
            $IC=$_POST['IC'];
            $MobilePhone=$_POST['MobilePhone'];
            $Email=$_POST['Email'];
            $Password=$_POST['Password'];
            $CPassword=['CPassword'];

			//validate empty field, string length, letters and numbers
            if(empty($FullName)){
                echo "<script>alert('Error: Full Name required!!!')</script>";
            }
            elseif(ctype_alpha(str_replace(' ', '', $FullName)) === false){
                echo"<script>alert('Error: Only letters are allowed for name!!!')</script>";
            }
            elseif(empty($IC)){
                echo "<script>alert('Error: IC required!!!')</script>";
            }
            elseif(!is_numeric($IC)){
                echo"<script>alert('Error: Only numbers are allowed for IC!!!')</script>";
            }
            elseif(strlen($IC)!=12){
                echo"<script>alert('Error: Invalid length!!! IC must have 12 numbers')</script>";
            }
            elseif(empty($MobilePhone)){
                echo "<script>alert('Error: Mobile Phone required!!!')</script>";
            }
            elseif(!is_numeric($MobilePhone)){
                echo"<script>alert('Error: Only numbers are allowed for phone number!!!')</script>";
            }
            elseif(strlen($MobilePhone)<10 || strlen($MobilePhone)>11 ){
                echo"<script>alert('Error: Invalid length!!! Phone number Must be in 10 or 11 numbers')</script>";
            }
            elseif(empty($Email)){
                echo "<script>alert('Error: Email required!!!')</script>";
            }
            elseif(empty($Password)){
                echo"<script>alert('Error: Password required!!!')</script>";
            }
            else{
				//validate strength of password
                $error="";
                if( strlen($Password) < 8 ) {
                    $error = "Password too short! Must at least 8 characters";
                }
                elseif( strlen($Password) > 20 ) {
                    $error = "Password too long! At most 20 characters";
                }
                elseif( !preg_match("#[0-9]+#", $Password) ) {
                    $error = "Password must include at least one number!";
                }
                elseif( !preg_match("#[a-z]+#", $Password) ) {
                    $error = "Password must include at least one letter!";
                }
				//display error message
                if($error){
                    echo "<script>alert('Password validation failure(your choise is weak): $error')</script>";
                }
                else{
					//validate password and confirm password
                    if($_POST['Password'] != $_POST['CPassword']){
                        echo "<script>alert('Your passwords did not match.')</script>";
                    }
                    else{
                        $query = mysqli_query($conn, "INSERT INTO register
					(name, ic, phone, email, password)VALUES
					('$FullName', '$IC', '$MobilePhone', '$Email', '$Password')");
                        if($query)
                        {
                            //display message to inform user
							echo "<script>alert('Account successfully created !!!')</script>";
                        }
                    }
                }
            }

        }
        ?>
        <!-- Start Sign Up Area -->
        <section class="home-about-area section-gap">
            <div class="box">
                <form method="post">
                    <span class="text-center">Sign-Up</span>
					<!--Prompt user enter Name-->
                    <div class="input-container">
                        <input type="text" placeholder="Enter Your Name" name="FullName">
                        <label for="FullName">Full Name</label>		
                    </div>
					<!--Prompt user enter IC-->
                    <div class="input-container">
                        <input type="text" name="IC" placeholder="Enter Your IC">
                        <label>IC</label>		
                    </div>
					<!--Prompt user enter Phone Number-->
                    <div class="input-container">
                        <input type="text" name="MobilePhone" placeholder="Enter Your Phone Number">
                        <label>Phone Number</label>		
                    </div>
					<!--Prompt user enter Email-->
                    <div class="input-container">
                        <input type="text" name="Email" placeholder="Enter Your Email">
                        <label>Email</label>		
                    </div>
					<!--Prompt user enter Password-->
                    <div class="input-container">
                        <input type="password" name="Password" placeholder="Enter Your Password">
                        <label>Password</label>		
                    </div>
					<!--Prompt user enter Confirm Password-->
                    <div class="input-container">
                        <input type="password" name="CPassword" placeholder="Re-enter Your Password">
                        <label>Confirm Password</label>		
                    </div>
					<!--SignUp Button-->
                    <button type="submit" class="btn" name="submit" value="Submit">Sign-Up</button><br><br>
					<!--Send user to login [age if have an account-->
                    <a href="login.php">Got account already?</a>
                </form>	
            </div>		
        </section>
        <!-- End sign up Area -->

        <section class="home-about-area section-gap"></section>
        <section class="home-about-area section-gap"></section>

        <?php
        include 'footer.html';
        ?>

    </body>
</html>