<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>Vroom Vroom</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
        <!--
CSS
============================================= -->
        <link rel="stylesheet" href="css/linearicons.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/nice-select.css">							
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">			
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/table1.css">

    </head>
    <body>	
        <?php

        include 'header.php';

        ?>

        <!-- start banner Area -->
        <section class="banner-area relative about-banner" id="home">	
            <div class="overlay overlay-bg"></div>
            <div class="container">				
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            Destination			
                        </h1>	
                        <p class="text-white link-nav"><a href="home.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="destination.php">Destination</a></p>
                    </div>
                </div>	
            </div>
        </section>
        <!-- End banner Area -->		

        <!--content-->
        <div class="whole-wrap">
            <div class="container">
                <div class="section-top-border">
                    <h1 align=center>Kuala Lumpur</h1>
                </div>
                <section class="georgetown">
                    <div class="section-top-border">
                        <h3 class="mb-30">Petronas Twin Towers</h3>
                        <div class="row">
                            <div class="col-md-3">
                                <img src="img/destination/kl1.jpg" alt="" class="img-fluid">
                            </div>
                            <div class="col-md-9 mt-sm-20 left-align-p">
                                <p>The most popular tourist attractions in Kulala Lumpur, the Petronas Twin Towers are the tallest twin structures in the world. With a whopping 88-storeys, these feature Skybridge- the double-decker connecting structure between the towers along with the headquarters for Petronas Company and other offices. Other several attractions include Kuala Lumpur Convention centre and Suria KLCC Mall.

                                    The towers have Islamic-inspired architecture and the area around them features the well-maintained KLCC Park. You can avail all these attractions and more, by exploring around with the help of a 170 meters elevator inside.</p>
                            </div>
                        </div>
                    </div>

                    <div class="section-top-border">
                        <h3 class="mb-30">Batu Caves</h3>
                        <div class="row">
                            <div class="col-md-3">

                                <img src="img/destination/kl2.jpg" alt="" class="img-fluid">
                            </div>
                            <div class="col-md-9 mt-sm-20 left-align-p">
                                <p>A 272-step long trek leads you to this century-old temple in limestone which is probably one of the most popular tourist spots in Kuala Lumpur. There are three big caves and numerous smaller ones here, with idols and statues erected inside.

                                    Amongst them, the Cathedral Cave is most frequented for its archaic 100m high arched ceiling and several Hindu shrines within. The others are the Art Gallery Cave and Museum Cave, with statues as well as ancient paintings to admire.</p>
                            </div>
                        </div>
                    </div>

                    <div class="section-top-border">
                        <h3 class="mb-30">Menara KL Tower</h3>
                        <div class="row">
                            <div class="col-md-3">
                                <img src="img/destination/kl3.jpg" alt="" class="img-fluid">
                            </div>
                            <div class="col-md-9 mt-sm-20 left-align-p">
                                <p>Giving tough competition to the Petronas is the Menara KL Tower, which stands high at 421 metres and offers spectacular views of the city from a height of 276 metres, which is much higher than the Petronas’ SkyBridge Viewpoint and it is one of the best places to visit in Kuala Lumpur.

                                    The tower’s glistening spindle-like apex can be spotted from anywhere in KL and the Islamic and Persian style architecture is sure to leave you in awe!

                                    The tower boasts of the tallest freestanding revolving restaurant, an amphitheatre, cascading pools, fast-food places and gift shops that certainly make it a highlight among the places to visit in KL</p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <!--content end-->
        <?php

        include 'footer.html';

        ?>

    </body>
</html>