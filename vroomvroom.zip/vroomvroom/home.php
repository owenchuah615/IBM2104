<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>Vroom Vroom</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
        <!--
CSS
============================================= -->
        <link rel="stylesheet" href="css/linearicons.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/nice-select.css">							
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">			
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/style.css">

    </head>
    <body>	
        <?php

        include 'header.php';

        ?>

        <!-- start banner Area -->
        <section class="banner-area relative" id="home">
            <div class="overlay overlay-bg"></div>
            <div class="container">
                <div class="row fullscreen d-flex align-items-center justify-content-between">
                    <div class="banner-content col-lg-6 col-md-6 ">
                        <h6 class="text-white ">Need a trip? Just Call Us</h6>
                        <h1 class="text-uppercase">
                            1188 333 8933				
                        </h1>
                        <p class="pt-10 pb-10 text-white">
                            A bus ride is like being in another world! Don't waste your energy on those who don't get on your bus.
                        </p>
                        <a href="order.php" class="primary-btn text-uppercase">Go to Order</a>
                    </div>										
                </div>
            </div>
        </section>
        <!-- End banner Area -->
        <br/><br/><br/><br/><br/><br/>
        <!-- Start services Area -->
        <section class="services-area pb-120">
            <div class="container">
                <div class="row section-title">
                    <h1>What Services we offer to our clients</h1>
                </div>
                <div class="row">
                    <div class="col-lg-4 single-service">
                        <span class="lnr lnr-bus"></span>
                        <a href="#"><h4>Bus Service</h4></a>
                    </div>
                    <div class="col-lg-4 single-service">
                        <span class="lnr lnr-map-marker"></span>
                        <a href="#"><h4>Destination Pick-ups</h4></a>
                    </div>
                    <div class="col-lg-4 single-service">
                        <span class="lnr lnr-star"></span>
                        <a href="#"><h4>Event Transportation</h4></a>
                    </div>												
                </div>	
            </div>	
        </section>
        <!-- End services Area -->

        <!-- Start services Area -->
        <section class="services-area pb-120">
            <div class="container">
                <div class="row section-title">
                    <h1>Popular Trip</h1>
                </div>
                <div class="row">
                    <div class="col-lg-4 single-service">
                        <span class="lnr lnr-map-marker"></span>
                        <a href="#"><h4>Georgetown</h4> <span class="lnr lnr-arrow-down"></span> <h4>Ipoh</h4></a>
                    </div>
                    <div class="col-lg-4 single-service">
                        <span class="lnr lnr-map-marker"></span>
                        <a href="#"><h4>Georgetown</h4> <span class="lnr lnr-arrow-down"></span> <h4>Kuala Lumpur</h4></a>
                    </div>
                    <div class="col-lg-4 single-service">
                        <span class="lnr lnr-map-marker"></span>
                        <a href="#"><h4>Ipoh</h4> <span class="lnr lnr-arrow-down"></span> <h4>Kuala Lumpur</h4></a>
                    </div>												
                </div>	
            </div>	
        </section>
        <!-- End services Area -->

        <!-- Start reviews Area -->
        <section class="reviews-area section-gap">
            <div class="container">
                <div class="row section-title">
                    <h1>Client’s Reviews</h1>
                </div>					
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="single-review">
                            <h4>Cody Hines</h4>
                            <p>
                                The process to rent the bus was smooth and they keep me updated with all the details leading up to the date of my trip. I received the bus driver’s information so I may get in contact with him before the time of the trip. The bus arrived on time, the driver was polite and communicated very well with us. We arrive to our destination in a timely matter.
                            </p>
                            <div class="star">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                            </div>
                        </div>
                    </div>	
                    <div class="col-lg-4 col-md-6">
                        <div class="single-review">
                            <h4>Chad Herrera</h4>
                            <p>
                                Great experience all the way around. Easy reservation, prompt return of phone calls and a great driver. It was for a birthday trip and it worked out perfectly.
                            </p>
                            <div class="star">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                        </div>
                    </div>	
                    <div class="col-lg-4 col-md-6">
                        <div class="single-review">
                            <h4>Andre Gonzalez</h4>
                            <p>
                                We had a wonderful day! What could have been super stressful was a breeze. We can’t imagine better service, support, or a better day of experience. Not to mention that the price was the best out there. We highly recommend busrental.com!
                            </p>
                            <div class="star">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                            </div>
                        </div>
                    </div>	
                    <div class="col-lg-4 col-md-6">
                        <div class="single-review">
                            <h4>Jon Banks</h4>
                            <p>
                                The bus was in great condition and very clean. The driver arrived ahead of schedule and got us to our destination on time. Most importantly we arrived there and back safely in a very comfortable bus. I would certainly use them for any future trips and highly recommended them to other groups for their transportation needs!								</p>
                            <div class="star">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                        </div>
                    </div>	
                    <div class="col-lg-4 col-md-6">
                        <div class="single-review">
                            <h4>Landon Houston</h4>
                            <p>
                                They made my wedding day amazing, arrived promptly, itinerary all to hand prior to arrival and the driver was very polite and helped wherever he could. Will definitely be using these guys in future, hopefully it's not for a second wedding lol! Most definitely recommend to anyone!
                            </p>
                            <div class="star">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                            </div>
                        </div>
                    </div>	
                    <div class="col-lg-4 col-md-6">
                        <div class="single-review">
                            <h4>Nelle Wade</h4>
                            <p>
                                Fast efficient company to rent a vehicle from they also give you ways to make money back like referring a friend and having time off work with free weeks rental. I highly recommend this company it was very easy to book with them great customer service and I will definitely use them again in the future
                            </p>
                            <div class="star">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                            </div>
                        </div>
                    </div>																															
                </div>
            </div>	
        </section>
        <!-- End reviews Area -->

        <!-- Start latest-blog Area -->
        <section class="latest-blog-area section-gap">
            <div class="container">
                <div class="row section-title">
                    <h1>Latest News from our Blog</h1>
                    <p>Who are in extremely love with eco friendly system.</p>
                </div>						
                <div class="row">
                    <div class="col-lg-6">
                        <div class="single-latest-blog">
                            <div class="thumb">
                                <img class="img-fluid" src="img/b1.jpg" alt="">
                            </div>
                            <ul class="tags">
                                <li><a href="#">Travel</a></li>
                                <li><a href="#">Life Style</a></li>
                            </ul>
                            <a href="#">
                                <h4>@modestmira_</h4>
                            </a>
                            <p>
                                Having good people around you who motivate, inspire and encourage you is so important. 
                                Surrounding yourself in that energy and environment is what will help you grow and really does have an impact on your mental state. 
                                So for instance if you’re leaving your set of friends and you feel more weighed down then you did before you saw them.. you need to let that shit go lol. 
                                I’m forever grateful for the people in my life but if at any point I feel they don’t add value or they have such a negative impact on me mentally especially, I know I have to let it go (as hard as it may be) you should always put yourself first.
                                But to ma girls love ya longtime babes 😘
                            </p>
                            <p class="date">1st July, 2020</p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="single-latest-blog">
                            <div class="thumb">
                                <img class="img-fluid" src="img/b2.jpg" alt="">
                            </div>
                            <ul class="tags">
                                <li><a href="#">Travel</a></li>
                                <li><a href="#">Life Style</a></li>
                            </ul>
                            <a href="#">
                                <h4>@kelseydashmarie</h4>
                            </a>
                            <p>
                                I’ve been really struggling to concentrate or find inspiration for the past two weeks — even simple joys, like reading, has been difficult. 
                                I’ve found that wearing colour is helping me find joy again. My recent fav is this beautiful blouse by @rixo — it’s amazing what a little colour can do.
                                #iconsofrixo #humansofrixo #iconofrixo
                            </p>
                            <p class="date">1st July, 2020</p>
                        </div>
                    </div>						
                </div>
            </div>	
        </section>
        <!-- End latest-blog Area -->

        <?php

        include 'footer.html';

        ?>

        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="js/vendor/bootstrap.min.js"></script>			
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
        <script src="js/easing.min.js"></script>			
        <script src="js/hoverIntent.js"></script>
        <script src="js/superfish.min.js"></script>	
        <script src="js/jquery.ajaxchimp.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>	
        <script src="js/jquery-ui.js"></script>								
        <script src="js/jquery.nice-select.min.js"></script>							
        <script src="js/mail-script.js"></script>	
        <script src="js/main.js"></script>	
    </body>
</html>