<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>Vroom Vroom</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
        <!--
CSS
============================================= -->
        <link rel="stylesheet" href="css/linearicons.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/nice-select.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/table.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>	
        <?php

        include 'header.php';
        ?>

        <!-- start banner Area -->
        <section class="banner-area relative about-banner" id="home">
            <div class="overlay overlay-bg"></div>
            <div class="container">
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            Purchase History
                        </h1>
                        <p class="text-white link-nav"><a href="home.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="contact.php">Purchase History</a></p>
                    </div>
                </div>
            </div>
        </section>
        <!-- End banner Area -->

        <!-- Start purchase history-page Area -->
        <div class="limiter">
            <div class="container-table100">
                <div class="wrap-table100">
                    <div class="table100">
                        <table align="center">
                            <thead>
                                <tr class="table100-head">
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Date </th>
                                    <th>Time</th>
                                    <th>Price</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php

                                //connect database
                                $db = mysqli_connect('localhost', 'root', '');
                                mysqli_select_db($db, 'vroomvroom');

                                //query to select the needed data from ordering database
                                $query = 'SELECT name,email,phone,date,time,total_price FROM ordering';

                                if ($r = mysqli_query($db, $query)) {
                                    while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
                                ?>
                                <!-- Display all purchase history done by users -->
                                <tr>
                                    <td><?php echo $row['name'] ?></td>
                                    <td><?php echo $row['email']; ?></td>
                                    <td><?php echo $row['phone']; ?></td>
                                    <td><?php echo $row['date']; ?></td>
                                    <td><?php echo $row['time']; ?></td>
                                    <td>RM<?php echo $row['total_price']; ?></td>
                                </tr>

                                <?php
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- End purchase history-page Area -->
        <?php

        include 'footer.html';
        ?>
    </body>
</html>
