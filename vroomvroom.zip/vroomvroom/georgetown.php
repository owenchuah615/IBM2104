<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>Vroom Vroom</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
        <!--
CSS
============================================= -->
        <link rel="stylesheet" href="css/linearicons.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/nice-select.css">							
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">			
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/table1.css">
        <link rel="stylesheet" href="css/style.css">

    </head>
    <body>	
        <?php

        include 'header.php';

        ?>

        <!-- start banner Area -->
        <section class="banner-area relative about-banner" id="home">	
            <div class="overlay overlay-bg"></div>
            <div class="container">				
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            Destination			
                        </h1>	
                        <p class="text-white link-nav"><a href="home.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="destination.php">Destination</a></p>
                    </div>
                </div>	
            </div>
        </section>
        <!-- End banner Area -->	

        <!--content-->
        <div class="whole-wrap">
            <div class="container">
                <div class="section-top-border">
                    <h1 align=center>Georgetown , Penang</h1>
                </div>
                <section class="penang">
                    <div class="section-top-border">
                        <h3 class="mb-30">Khoo Khongsi</h3>
                        <div class="row">
                            <div class="col-md-3">
                                <img src="img/destination/penang1.jpg" alt="" class="img-fluid">
                            </div>
                            <div class="col-md-9 mt-sm-20 left-align-p">
                                <p>Penang’s Khoo Khongsi is a Chinese clanhouse for individuals with the surname Khoo. A clanhouse acts as a representation of a specific family’s social and spiritual commitments between extended relations, ancestors and the outside community. Also known as Dragon Mountain Hall, it represents good luck and wealth, with stone carvings that adorn the entrance hall and pavilions. Murals portraying birthdays, weddings and, most memorably, the 36 divine guardians sprinkle the interior. Overhead, massive paper lamps cast the clanhouse in an orange glow and stunning ceramic sculptures of immortals, carp fish and dragons dance across the roof ridges.</p>
                            </div>
                        </div>
                    </div>

                    <div class="section-top-border">
                        <h3 class="mb-30">Penang Hill</h3>
                        <div class="row">
                            <div class="col-md-3">
                                <img src="img/destination/penang2.jpg" alt="" class="img-fluid">
                            </div>
                            <div class="col-md-9 mt-sm-20 left-align-p">
                                <p>Penang Hill, or Flagstaff Hill (Bukit Bendera) as it is officially known, rises 821 metres above sea level, providing a welcome break from the heat below. One of Penang’s most popular attractions, a trip up is a not-to-be-missed experience, providing visitors with breathtaking views of the whole island all the way to the top. The best way to reach the summit is to hop onboard the funicular train that travels all the way up in half an hour. Highlights at the peak include a pretty Hindu temple, church, mosque and even a snake show where you can take photos with a tame python for a fee</p>
                            </div>
                        </div>
                    </div>

                    <div class="section-top-border">
                        <h3 class="mb-30">Kek Lok Si Temple</h3>
                        <div class="row">
                            <div class="col-md-3">
                                <img src="img/destination/penang3.jpg" alt="" class="img-fluid">
                            </div>
                            <div class="col-md-9 mt-sm-20 left-align-p">
                                <p>Amongst the largest Buddhist temple complex in Southeast Asia, Kek Lok Si Temple stands on top of a hill in the little town of Air Itam. Founded more than a hundred years ago, the complex is filled with beautifully-landscaped gardens and sacred temples. A striking seven-tiered pagoda called The Pagoda of 1000 Buddhas -  which combines Thai, Chinese and Burmese styles in one structure - houses a stunning collection of Buddha statues made from all sorts of precious materials. Also found within the temple complex are the statues of The Four Heavenly Kings, guarding the four points of the compass - North, South, West and East - with the statue of The Laughing Buddha in the middle.</p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <!--content end-->
        <?php

        include 'footer.html';

        ?>

        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="js/vendor/bootstrap.min.js"></script>			
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
        <script src="js/easing.min.js"></script>			
        <script src="js/hoverIntent.js"></script>
        <script src="js/superfish.min.js"></script>	
        <script src="js/jquery.ajaxchimp.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>	
        <script src="js/jquery-ui.js"></script>								
        <script src="js/jquery.nice-select.min.js"></script>							
        <script src="js/mail-script.js"></script>	
        <script src="js/main.js"></script>	
    </body>
</html>