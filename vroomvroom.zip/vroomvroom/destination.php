<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>Vroom Vroom</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
        <!--
CSS
============================================= -->
        <link rel="stylesheet" href="css/linearicons.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/nice-select.css">							
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">			
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/table.css">
        <link rel="stylesheet" href="css/style.css">

    </head>
    <body>	
        <?php

        include 'header.php';

        ?>

        <!-- start banner Area -->
        <section class="banner-area relative about-banner" id="home">	
            <div class="overlay overlay-bg"></div>
            <div class="container">				
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            Destination			
                        </h1>	
                        <p class="text-white link-nav"><a href="home.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="destination.php">Destination</a></p>
                    </div>
                </div>	
            </div>
        </section>
        <!-- End banner Area -->	


        <!-- Start destination page Area -->
        <div class="limiter">
            <div class="container-table100">
                <div class="wrap-table100">
                    <h3>Places to Go</h3><br><br>
                    <div class="table100">

                        <table align="center">
                            <thead>
                                <tr class="table100-head">
                                    <th>Destination</th>
                                    <th>State</th>
                                    <th>Rating</th>
                                    <th>Availability</th>

                                </tr>
                            </thead>
                            <tbody>

                                <?php

                                //connect to database
                                $db = mysqli_connect('localhost', 'root', '');
                                mysqli_select_db($db, 'vroomvroom');

                                //select all data from destination database
                                $query = 'SELECT * FROM destination ';

                                if ($r = mysqli_query($db, $query)) {
                                    while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
                                ?>
                                <!-- Display all data selected -->
                                <tr>
                                    <td><?php echo $row['destination']; ?></td>
                                    <td><?php echo $row['state']; ?></td>
                                    <td><?php echo $row['rating']; ?>/10</td>
                                    <td><?php echo $row['availability']; ?></td>                              
                                </tr>
                                <?php
                                    }
                                }
                                ?>

                            </tbody>
                        </table>
                        <br><br><br><br>
                        <h3>Destination Prices</h3><br><br>
                        <table>
                            <thead>
                                <tr class="table100-head">
                                    <th></th>
                                    <th>Georgetown,Penang</th>
                                    <th>Ipoh,Perak</th>
                                    <th>Alor Setar,Kedah</th>
                                    <th>Kuala Lumpur,Selangor</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>Georgetown,Penang</th>
                                    <td>-</td>
                                    <td>RM15</td>
                                    <td>RM10</td>
                                    <td>RM18</td>
                                </tr>

                                <tr>
                                    <th>Ipoh,Perak</th>
                                    <td>RM15</td>
                                    <td>-</td>
                                    <td>RM5</td>
                                    <td>RM12</td>
                                </tr>

                                <tr>
                                    <th>Alor Setar,Kedah</th>
                                    <td>RM10</td>
                                    <td>RM5</td>
                                    <td>-</td>
                                    <td>RM15</td>
                                </tr>

                                <tr>
                                    <th>Kuala Lumpur,Selangor</th>
                                    <td>RM18</td>
                                    <td>RM15</td>
                                    <td>RM12</td>
                                    <td>-</td>
                                </tr>
                            </tbody>
                        </table>
                        <br><br><br><br>
                        <h3>Click in to see descriptions of the places!</h3><br><br>
                        <table align="center">
                            <tr>
                                <th><a href=georgetown.php>Georgetown,Penang</a></th>
                                <th><a href=ipoh.php>Ipoh,Perak</a></th>
                                <th><a href=kedah.php>Alor Setar,Kedah</a></th>
                                <th><a href=kl.php>Kuala Lumpur,Selangor</a></th>
                            </tr>
                            <tbody>
                                <tr>
                                    <td><a href=georgetown.php><img src="img/destination/georgetown.jpg" width="300px" height="200px"></a></td>
                                    <td><a href=ipoh.php><img src="img/destination/ipoh.jpg" width="300px" height="200px"></a></td>
                                    <td><a href=kedah.php><img src="img/destination/alorsetar.jpg" width="300px" height="200px"></a></td>
                                    <td><a href=kl.php><img src="img/destination/selangor.jpg" width="300px" height="200px"></a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>


            </div>      
        </div>																		

        <!-- End destination page Area -->
        <?php

        include 'footer.html';

        ?>

    </body>
</html>