<?php
if (isset($_POST['submitted'])) {
    
    //connect database
    $db = mysqli_connect('localhost', 'root', '');
    mysqli_select_db($db, 'vroomvroom');

    //variable names
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    $status = true;

    //query to insert all the input data into database
    $query = "INSERT INTO contact(name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message')";

    //input fields cannot be empty
    if(empty($name)){
        echo "<script>alert('Error: Full Name required!!!')</script>";
        $status = false;
    }
    //if name is not input with alphabets display error message
    //allow user to type in space for their names
    elseif(ctype_alpha(str_replace(' ', '', $name)) === false){
        echo"<script>alert('Error: Only letters are allowed!!!')</script>";
        $status = false;
    }

    if (empty($email)) {
        echo "<script>alert('Error: Email required!!!')</script>";
        $status = false;
    }

    if (empty($subject)) {
        echo "<script>alert('Error: Subject required!!!')</script>";
        $status = false;
    }

    if (empty($message)) {
        echo "<script>alert('Error: Message required!!!')</script>";
        $status = false;
    }
}
?>


<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>Vroom Vroom</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
        <!--
CSS
============================================= -->
        <link rel="stylesheet" href="css/linearicons.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/nice-select.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/table1.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>	

        <?php

        include 'header.php';
        ?>

        <!-- start banner Area -->
        <section class="banner-area relative about-banner" id="home">
            <div class="overlay overlay-bg"></div>
            <div class="container">
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            Contact Us
                        </h1>
                        <p class="text-white link-nav"><a href="index.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="contact.php"> Contact Us</a></p>
                    </div>
                </div>
            </div>
        </section>
        <!-- End banner Area -->

        <!-- Start contact-page Area -->
        <section class="contact-page-area section-gap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 d-flex flex-column address-wrap">
                        <div class="single-contact-address d-flex flex-row">
                            <div class="icon">
                                <span class="lnr lnr-home"></span>
                            </div>
                            <div class="contact-details">
                                <h5>Bayan Lepas, Penang</h5>
                                <p>
                                    12 Jalan Abu, Taman Dua
                                </p>
                            </div>
                        </div>
                        <div class="single-contact-address d-flex flex-row">
                            <div class="icon">
                                <span class="lnr lnr-phone-handset"></span>
                            </div>
                            <div class="contact-details">
                                <h5>012-3456789</h5>
                                <h5>017-5647042</h5>
                                <p>Monday to Friday 10 am to 5 pm</p>
                            </div>
                        </div>
                        <div class="single-contact-address d-flex flex-row">
                            <div class="icon">
                                <span class="lnr lnr-envelope"></span>
                            </div>
                            <div class="contact-details">
                                <h5>support@vroomvroom.com</h5>
                                <p>Send us your query anytime!</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <form class="form-area contact-form text-right" action="contact.php" method="post">
                            <div class="row">
                                <div class="col-lg-6 form-group">
                                    <input name="name" placeholder="Enter your name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your name'" class="common-input mb-20 form-control" type="text">

                                    <input name="email" placeholder="Enter email address" pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email address'" class="common-input mb-20 form-control" type="email">

                                    <input name="subject" placeholder="Enter subject" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter subject'" class="common-input mb-20 form-control" required="" type="text">
                                </div>
                                <div class="col-lg-6 form-group">
                                    <textarea class="common-textarea form-control" name="message" placeholder="Enter Messege" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Messege'"></textarea>
                                </div>
                                <div class="col-lg-12">
                                    <div class="alert-msg" style="text-align: left;"></div>
                                    <button type="submit" class="genric-btn primary" style="float: right;">Send Message</button>
                                    <input type="hidden" name="submitted" value="true">
                                </div>
                            </div>
                            <?php
                            if (isset($_POST['submitted'])) {
                                //if query successfully executed,display success message
                                if (mysqli_query($db, $query)) {
                                    echo "<script>alert('The message has been added!!!!')</script>";
                                }
                                else {
                                    echo "<script>Could not add the entry becuase:<br>".mysqli_error($db).".</p>
										<p>The query was:".$query."</script>";
                                }
                                mysqli_close($db);
                            }

                            ?>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- End contact-page Area -->

        <?php
        include 'footer.html';
        ?>

    </body>
</html>
