<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Vroom Vroom</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/jquery-ui.css">			
			<link rel="stylesheet" href="css/main.css">
            <link rel="stylesheet" href="css/table1.css">
   
		</head>
		<body>	
			  <?php
            
            include 'header.php';
            
            ?>
			  
			<!-- start banner Area -->
			<section class="banner-area relative about-banner" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Destination			
							</h1>	
							<p class="text-white link-nav"><a href="home.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="destination.php">Destination</a></p>
                            </div>
						</div>	
                </div>
			</section>
			<!-- End banner Area -->	
            
            <!--content-->
            <div class="whole-wrap">
				<div class="container">
					<div class="section-top-border">
                        <h1 align=center>Ipoh , Perak</h1>
                    </div>
                        <section class="perak">
                        <div class="section-top-border">
						<h3 class="mb-30">Malaysia’s Leaning Tower (Teluk Intan)</h3>
						<div class="row">
							<div class="col-md-3">
								<img src="img/destination/perak1.jpg" alt="" class="img-fluid">
							</div>
							<div class="col-md-9 mt-sm-20 left-align-p">
								<p>Italy has the Leaning Tower of Pisa; Perak has The Leaning Tower of Teluk Intan.

Standing at 25.5 meters (84 feet) in Teluk Intan, the tower is a statewide monument.

The pagoda-like tower opened in 1885 as a water tank. Over time, its weight caused one side to sink into the soft ground.

Today it has a slight leftwards tilt and serves as a clock tower.

Leaning Tower of Teluk Intan is just under 90 kilometers (56 miles) south of Ipoh.

Stop by while traveling to or from Kuala Lumpur.</p>
							</div>
						</div>
                            </div>
                        
                        <div class="section-top-border">
						
                                <h3 class="mb-30">Lost World Of Tambun</h3>
                            <div class="row">
							<div class="col-md-3">
								<img src="img/destination/perak2.jpg" alt="" class="img-fluid">
							</div>
							<div class="col-md-9 mt-sm-20 left-align-p">
								<p>More than just a theme park, it’s a destination!
Lost World Of Tambun is an action packed, wholesome family adventure destination. This self-contained wonderland is cocooned by lush tropical jungle, natural hot springs, breathtaking limestone features of 400 million years of age and seven amazing attraction parks making it the ultimate day and night destination for a unique eco-adventure excursion for visitors of all ages. Just a stone’s throw away is the Lost World Hotel, a perfect snooze chamber after a long day of adventure.

Lost World Of Tambun offers not only a “lost paradise” that promises fun and wholesome experience for all ages but also a conducive learning environment with a range of fun educational elements around the park. We are also the only theme park in Southeast Asia with natural hot springs coupled with an array of attractions and rides.</p>
							</div>
						</div>
                            </div>
        
                        <div class="section-top-border">
                        <h3 class="mb-30">Kellie's Castle</h3>
						<div class="row">
							<div class="col-md-3">
								<img src="img/destination/perak3.jpg" alt="" class="img-fluid">
							</div>
							<div class="col-md-9 mt-sm-20 left-align-p">
								<p>Kellie’s Castle is an eerie and allegedly haunted colonial mansion near Ipoh.

An eccentric Scotsman migrated to British Malaya in the early 20th-century becoming wealthy from his rubber plantations. William Kellie Smith commissioned this mansion in Batu Gajah located 21 kilometers (13 miles) from Ipoh.

The colonial structure blends Moorish, Roman and British Indian architectural styles.

Smith suddenly died. His family returned to Britain. The half-finished mansion remained unfinished. Before long, the jungle swallowed it.

Visitors can walk through the multi-storied structure and stand on the rooftop tennis court. Rumors suggest ghosts roam the abandoned hallways. Or the house has undiscovered secret passageways.

Take a cab or Grab Car from Ipoh. Negotiate a price to wait for one hour.</p>
							</div>
						</div>
                            </div>
                        </section>
					</div>
                </div>
            <!--content end-->
            <?php
            
            include 'footer.html';
            
            ?>

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
 			<script src="js/jquery-ui.js"></script>								
			<script src="js/jquery.nice-select.min.js"></script>							
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>