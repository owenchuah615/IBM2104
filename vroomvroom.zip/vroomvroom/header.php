<?php
//start session
session_start();

//if there are email input
if(isset($_SESSION['email'])){

    $Email=$_SESSION['email'];
}
?>

<!-- start header !-->
<header id="header">
    <div class="header-top">
    </div>
    <div class="container main-menu">
        <div class="row align-items-center justify-content-between d-flex">
            <p class="text-white" size="33">Vroom Vroom</p>		
            <nav id="nav-menu-container">
                <ul class="nav-menu">
                    <li class="menu-active"><a href="home.php">Home</a></li>
                    <li><a href="signup.php">Sign Up</a></li>
                    <li><a href="destination.php">Destinations</a></li>
                    <li><a href="bus.php">Buses</a></li>		
                    <li><a href="contact.php">Contact Us</a></li>	  	
                    <li><a href="about.php">About Us</a></li>	          
                    <li><a href="order.php">Order</a></li>
                    <li><a href="cart.php">Cart</a></li>
                    <li><a href="history.php">Purchase History</a></li>	
                    <?php 

                    //if user successfully signed in,display log out button
                    if(isset($Email)){
                        echo"<li><a href='logout.php'><button class='btn2'/>Log Out</button></a></li>";
                    }
                    //if not display login button
                    else{

                        echo"<li><a href='login.php'><button class='btn1'>Login</button></a></li>";
                    }
                    ?>
                </ul>
            </nav>		
        </div>
    </div>
</header>
<!-- end header -->