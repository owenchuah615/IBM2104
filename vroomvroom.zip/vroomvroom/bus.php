<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>Vroom Vroom</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
        <!--
CSS
============================================= -->
        <link rel="stylesheet" href="css/linearicons.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/nice-select.css">							
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">			
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/table.css">
        <link rel="stylesheet" href="css/style.css">

    </head>
    <body>	
        <?php

        include 'header.php';

        ?>

        <!-- start banner Area -->
        <section class="banner-area relative about-banner" id="home">	
            <div class="overlay overlay-bg"></div>
            <div class="container">				
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            Bus				
                        </h1>	
                        <p class="text-white link-nav"><a href="home.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="bus.php">Bus</a></p>
                    </div>	
                </div>
            </div>
        </section>
        <!-- End banner Area -->	



        <!-- Start bus page Area -->
        <div class="limiter">
            <div class="container-table100">
                <div class="wrap-table100">
                    <h3>Types of Buses</h3><br><br>
                    <div class="table100">
                        <table align="center">
                            <thead>
                                <tr class="table100-head">

                                    <th>Bus Types</th>
                                    <th>Seating</th>
                                    <th>Restroom</th>
                                    <th>WiFi</th>
                                    <th>Charger</th>
                                    <th>Availability</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php

                                //connect to database
                                $db = mysqli_connect('localhost', 'root', '');
                                mysqli_select_db($db, 'vroomvroom');

                                //select all data from bus database
                                $query = 'SELECT * FROM bus ';

                                if ($r = mysqli_query($db, $query)) {
                                    while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
                                ?>
                                <tr>
                                    <!-- Display all data selected -->
                                    <td><?php echo $row['bus_type']; ?></td>
                                    <td><?php echo $row['seating']; ?></td>
                                    <td><?php echo $row['restroom']; ?></td>
                                    <td><?php echo $row['wifi']; ?></td>
                                    <td><?php echo $row['charger']; ?></td>
                                    <td><?php echo $row['availability']; ?></td>


                                </tr>
                                <?php
                                    }
                                }
                                ?>

                            </tbody>
                        </table>

                        <br><br><br><br>
                        <table align="center">
                            <tbody>
                                <tr>
                                    <th>Bus A</th>
                                    <th>Bus B</th>
                                    <th>Bus C</th>
                                    <th>Bus D</th>
                                </tr>

                                <tr>
                                    <td><img src="img/bus/busA.jpg" width="300px" height="200px"></td>
                                    <td><img src="img/bus/busB.jpg" width="300px" height="200px"></td>
                                    <td><img src="img/bus/busC.jpg" width="300px" height="200px"></td>
                                    <td><img src="img/bus/busD.jpg" width="300px" height="200px"></td>
                                </tr>

                                <tr>
                                    <td>RM6</td>
                                    <td>RM9</td>
                                    <td>RM5</td>
                                    <td>RM3</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>


            </div>
        </div>									

        <!-- End bus page Area -->
        <?php

        include 'footer.html';

        ?>

    </body>
</html>