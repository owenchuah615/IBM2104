<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>Vroom Vroom</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
        <!--
CSS
============================================= -->
        <link rel="stylesheet" href="css/linearicons.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/nice-select.css">							
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">			
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/style.css">

    </head>
    <body>	
        <?php

        include 'header.php';
        ?>

        <!-- start banner Area -->
        <section class="banner-area relative about-banner" id="home">	
            <div class="overlay overlay-bg"></div>
            <div class="container">				
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            Order	
                        </h1>	
                        <p class="text-white link-nav"><a href="index.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="about.php">Order</a></p>
                    </div>	
                </div>
            </div>
        </section>
        <!-- End banner Area -->	

        <?php

        //connect database
        $conn=mysqli_connect("localhost", "root", "", "vroomvroom");
        if($conn->connect_error){
            die("Connection failed:". $conn-> connect_error);
        }

        if (isset($_POST['submitted'])) {

            //variable names
            $name=$_POST['name'];
            $email=$_POST['email'];
            $quantity=$_POST['quantity'];
            $phone=$_POST['phone'];
            $trip=$_POST['trip'];
            $bustype=$_POST['bustype'];
            $from=$_POST['from'];
            $to=$_POST['to'];
            $date=$_POST['date'];
            $time=$_POST['time'];

            //input fields cannot be empty
            if(empty($name)){
                echo "<script>alert('Error: Full Name required!!!')</script>";
            }
            //if name is not input with alphabets display error message
            //allow user to type in space for their names
            elseif(ctype_alpha(str_replace(' ', '', $name)) === false){
                echo"<script>alert('Error: Only letters are allowed for name!!!')</script>";
            }
            elseif(empty($email)){
                echo "<script>alert('Error: Email required!!!')</script>";
            }
            elseif(empty($phone)){
                echo "<script>alert('Error: Mobile Phone required!!!')</script>";
            }
            //if HP is not input with numbers display error message
            elseif(!is_numeric($phone)){
                echo"<script>alert('Error: Only numbers are allowed for phone number!!!')</script>";
            }
            //if HP is not 10 or 11 characters display error message
            else if(strlen($phone) <10||strlen($phone) >11){
                echo"<script>alert('Error: Only 10 or 11 numbers for your HP!!!')</script>";
            }
            elseif(empty($quantity)){
                echo"<script>alert('Error: Please select the quantity!!!')</script>";
            }

            elseif(empty($trip)){
                echo "<script>alert('Error: Please select your trip type!!!')</script>";
            }
            elseif(empty($bustype)){
                echo"<script>alert('Error: Please select your bus type!!!')</script>";
            }
            elseif(empty($from)){
                echo"<script>alert('Error: Please select your destination!!!')</script>";
            }
            elseif(empty($to)){
                echo "<script>alert('Error: Please select your starting point!!!')</script>";
            }
            //destination and starting point cannot be the same
            elseif($to == $from){
                echo "<script>alert('Error: Cannot select same starting point and destination!!!')</script>";
            }
            elseif(empty($date)){
                echo"<script>alert('Error: Please select your date!!!')</script>";
            }
            //the booking order date must be after today 
            elseif(strtotime($date) < strtotime('now') ) {
                echo"<script>alert('Error: Please select a valid date!!!')</script>";
            }
            elseif(empty($time)){
                echo "<script>alert('Error: Please select your time!!!')</script>";
            }
            else{
                //calculate bus price
                if($bustype == 'A'){
                    $busprice= 6;
                }

                elseif($bustype == 'B'){
                    $busprice= 9;
                }

                elseif($bustype == 'C'){
                    $busprice= 5;
                }

                else{
                    $busprice= 3;
                }

                //calculate to see if customers chose one way trip or round trip
                if($trip=='Round Trip'){
                    $tripcost=2;
                }
                else{
                    $trip=='One Way';
                    $tripcost=1;
                }

                //calculate trip price
                if($from == 'Georgetown,Penang' && $to =='Alor Setar,Kedah'){
                    $tripprice=10;
                }
                elseif($from == 'Georgetown,Penang' && $to =='Ipoh,Perak'){
                    $tripprice=15;
                }
                elseif($from == 'Georgetown,Penang' && $to =='Kuala Lumpur,Selangor'){
                    $tripprice=18;
                }
                elseif($from == 'Alor Setar,Kedah' && $to =='Georgetown,Penang'){
                    $tripprice=10;
                }
                elseif($from == 'Alor Setar,Kedah' && $to =='Ipoh,Perak'){
                    $tripprice=5;
                }
                elseif($from == 'Alor Setar,Kedah' && $to =='Kuala Lumpur,Selangor'){
                    $tripprice=15;
                }
                elseif($from == 'Ipoh,Perak' && $to =='Georgetown,Penang'){
                    $tripprice=15;
                }
                elseif($from == 'Ipoh,Perak' && $to =='Alor Setar,Kedah'){
                    $tripprice=5;
                }
                elseif($from == 'Ipoh,Perak' && $to =='Kuala Lumpur,Selangor'){
                    $tripprice=12;
                }
                elseif($from == 'Kuala Lumpur,Selangor' && $to =='Georgetown,Penang'){
                    $tripprice=18;
                }
                elseif($from == 'Kuala Lumpur,Selangor' && $to =='Alor Setar,Kedah'){
                    $tripprice=15;
                }
                else{
                    $tripprice=12;
                }

                //calculate total price customers need to pay
                $totalprice=($busprice+$tripprice)*$quantity*$tripcost;

                //query to insert the order data into database
                $query = mysqli_query($conn,"INSERT INTO ordering(name, email, quantity,phone,trip,bus_type,start_point,destination,date,time,total_price) 

            VALUES ('$name', '$email', '$quantity', '$phone','$trip', '$bustype', '$from', '$to','$date','$time',$totalprice)");

                //if success display success output message
                if ($query) {
                    print "<script>alert('Order has been added to cart.')</script>";
                    print "<meta http-equiv='refresh' content='0;url=cart.php'>";
                }
                else {
                    echo "<script>alert('Could not add the entry because: ".mysqli_error($conn)."')</script>";
                }
                mysqli_close($conn);

            }
        }

        ?>
        <!-- Start order-page Area -->
        <div class= "col-md-6 header-right offset-lg-1 col-lg-10" >
            <div class= "container">
                <h4 class="pb-30" align="center" >Book Your Bus Online Now!</h4>
                <form action="order.php" method="POST" class="form"> 
                    <div class="from-group">
                        <input class="form-control txt-field" type="text" name="name" placeholder="Your name" >
                        <input class="form-control txt-field" type="email" name="email" placeholder="Email address" >
                        <input class="form-control txt-field" type="tel" name="phone" placeholder="Phone number" >
                        <input class="form-control txt-field" type="number" name="quantity" placeholder="Quantity" >
                        <div class="form-group">
                            <div class="default-select" id="default-select">
                                <select name="trip">
                                    <option value="" selected>Trip</option>
                                    <option value="One Way">One Way</option>
                                    <option value="Round Trip">Round Trip</option>
                                </select>
                            </div>
                        </div>						
                        <div class="form-group">
                            <div class="default-select" id="default-select">
                                <select name="bustype"> 
                                    <option value="" selected>Type of Bus</option>
                                    <option value="A">A</option>
                                    <option value="B">B</option>
                                    <option value="C">C</option>
                                    <option value="D">D</option>
                                </select>
                            </div>
                        </div>									
                        <div class="form-group">
                            <div class="default-select" id="default-select">
                                <select name="from">
                                    <option value="" selected>From</option>
                                    <option value="Georgetown,Penang">Georgetown,Penang</option>
                                    <option value="Alor Setar,Kedah">Alor setar,Kedah</option>
                                    <option value="Ipoh,Perak">Ipoh,Perak</option>
                                    <option value="Kuala Lumpur,Selangor">Kuala Lumpur,Selangor</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="default-select" id="default-select2">
                                <select name="to">
                                    <option value="" selected>To</option>
                                    <option value="Georgetown,Penang">Georgetown,Penang</option>
                                    <option value="Alor Setar,Kedah">Alor setar,Kedah</option>
                                    <option value="Ipoh,Perak">Ipoh,Perak</option>
                                    <option value="Kuala Lumpur,Selangor">Kuala Lumpur,Selangor</option>
                                </select>
                            </div>
                        </div>							    
                        <div class="form-group">
                            <div class="input-group dates-wrap">                                              
                                <input type="date" id="datepicker2" name="date" class="dates form-control"  placeholder="Date" type="text">                        
                                <div class="input-group-prepend">
                                    <span  class="input-group-text"><span class="lnr lnr-calendar-full"></span></span>
                                </div>											
                            </div>
                        </div>	
                        <div class="form-group">
                            <div class="default-select" id="default-select">
                                <select name="time">
                                    <option value="" selected>Time</option>
                                    <option value="08:00">8am</option>
                                    <option value="20:00">8pm</option>
                                </select>
                            </div>
                        </div>	
                        <div class="form-group">
                            <br><br>
                            <!--submit button!-->
                            <input type="submit" name="submitted" value="Add to Cart" class="btn btn-default btn-lg btn-block text-center text-uppercase" >

                        </div>
                    </div>

                </form>
            </div>
        </div>

        <!-- End order-page Area -->
        <?php
        include 'footer.html';
        ?>


    </body>
</html>