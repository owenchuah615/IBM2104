<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>Vroom Vroom</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
        <!--
CSS
============================================= -->
        <link rel="stylesheet" href="css/linearicons.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/nice-select.css">							
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">			
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>	
        <?php
        include 'header.php';
        ?>

        <!-- start banner Area -->
        <section class="banner-area relative about-banner" id="home">	
            <div class="overlay overlay-bg"></div>
            <div class="container">				
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            About Us	
                        </h1>	
                        <p class="text-white link-nav"><a href="home.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="about.php">About Us</a></p>
                    </div>	
                </div>
            </div>
        </section>
        <!-- End banner Area -->	

        <!-- Start Sample Area -->
        <section class="sample-text-area">
            <div class="container">
                <h3 class="text-heading">History of Vroom Vroom</h3>
                <p class="sample-text">
                    Vroom Vroom was founded in 2000 by Owen,Kuan Shin,Zi Ming and Yong Siang,who also worked together at various organisations before founding the company.With an investment of RM50000,the founders began the operation in 2010,by tying up with travel agents for seat reservations through the Vroom portal.Vroom Vroom has been serving the community for 20 years From a small bus station to a worldwide franchaise.Since 2007,Vroom Vroom has developed an online bus booking system.
                </p>
            </div>
        </section>
        <!-- End Sample Area -->

        <!-- Start Align Area -->
        <div class="whole-wrap">
            <div class="container">
                <div class="section-top-border">
                    <h3 class="mb-30">Funding from the Malaysia Government</h3>
                    <div class="row">
                        <div class="col-md-3">
                            <img src="img/malaysia.png" alt="" class="img-fluid">
                        </div>
                        <div class="col-md-9 mt-sm-20 left-align-p">
                            <p>In 2007,Vroom Vroom received its first funding of RM100,000 from the Malaysia Government.Vroom Vroom is also the official Malaysia bus company.</p>
                        </div>
                    </div>
                </div>
                <div class="section-top-border text-left">
                    <h3 class="mb-30">Southeast Asia Domination</h3>
                    <div class="row">
                        <div class="col-md-3">
                            <img src="img/map.jpg" alt="" class="img-fluid">
                        </div>
                        <div class="col-md-9 mt-sm-20 left-align-p">
                            <p>Vroom Vroom has now over 2000 bus stations all over Southeast Asia which is the most out of all other bus companies </p>

                        </div>
                    </div>
                </div>
                <div class="section-top-border" >
                    <h3 class="mb-30">Founders' wishes for Vroom Vroom in 2000 </h3>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="single-defination">
                                <h4 class="mb-20">Owen Chuah</h4>
                                <p>I am aiming for Vroom Vroom to become the best bus company in Malaysia</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="single-defination">
                                <h4 class="mb-20">Tan Kuan Shin</h4>
                                <p>They are very good friends and partners of mine,I hope we become successful one day</p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="single-defination">
                                <h4 class="mb-20">Ong Zi Ming</h4>
                                <p>We will make Vroom Vroom the best bus company ever</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="single-defination">
                                <h4 class="mb-20">Lai Yong Siang</h4>
                                <p>Vroom Vroom will the best and we believe in it </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- End Align Area -->

        <?php
        include 'footer.html';
        ?>

        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="js/vendor/bootstrap.min.js"></script>			
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
        <script src="js/easing.min.js"></script>			
        <script src="js/hoverIntent.js"></script>
        <script src="js/superfish.min.js"></script>	
        <script src="js/jquery.ajaxchimp.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>	
        <script src="js/jquery-ui.js"></script>								
        <script src="js/jquery.nice-select.min.js"></script>							
        <script src="js/mail-script.js"></script>	
        <script src="js/main.js"></script>			
    </body>
</html>