<?php
if(isset($_POST["submit"])){

    //validate empty fields
    if(empty($_POST['email'])){
        echo "<script>alert('Error: Email required!!!')</script>";
    }
    elseif(empty($_POST['password'])){
        echo "<script>alert('Error: Password required!!!')</script>";
    }
    else{
        $Email=$_POST['email'];
        $Password=$_POST['password'];

        $Email=stripcslashes($Email);
        $Password=stripcslashes($Password);

        //connect to database
        $conn=mysqli_connect("localhost", "root", "", "vroomvroom");

        $res=mysqli_query($conn,"SELECT * from register WHERE email='$Email' and password = '$Password'");
        $row=mysqli_fetch_array($res);

        //validate entered info same as database
        if($row['email'] == $Email && $row['password'] == $Password){
            //Successful message and send user to home page
            echo"<script>alert('Successfully Login!!!')
			window.location.href='home.php'</script>";  
            session_start();
            $_SESSION['email']=$_POST['email'];

            exit();
        }
        else{
            //Error message and remain at login page
            echo"<script>alert('Failed to Login!!!')
			window.location.href='login.php'</script>";
        }
    }


}
?>

<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>Vroom Vroom</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
        <!--
CSS
============================================= -->
        <link rel="stylesheet" href="css/linearicons.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/nice-select.css">							
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">			
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>	
        <?php

        include 'header.php';
        ?>

        <!-- start banner Area -->
        <section class="banner-area relative about-banner" id="home">	
            <div class="overlay overlay-bg"></div>
            <div class="container">				
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            Log In				
                        </h1>	
                        <p class="text-white link-nav"><a href="index.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="about.php"> Log In</a></p>
                    </div>	
                </div>
            </div>
        </section>
        <!-- End banner Area -->	

        <!-- Start Login Area -->
        <section class="home-about-area section-gap">
            <div class="box">
                <!--Login Form-->
                <form method="post">
                    <span class="text-center">Login</span>
                    <!--Prompt user to enter their Email-->
                    <div class="input-container">
                        <input type="text" placeholder="Enter Your Email" name="email">
                        <label for="Email">Email</label>		
                    </div>
                    <!--Prompt user to enter their Password-->
                    <div class="input-container">
                        <input type="password" name="password" placeholder="Enter Your Password">
                        <label>Password</label>		
                    </div>
                    <!--Submit Button-->
                    <button type="submit" class="btn" name="submit" value="Submit">Login</button><br><br>
                    <!--If user does not have account, "Account" can send user to Sign-Up page-->
                    <span class="psw">Create new <a href="signup.php">Account</a>!</span>
                </form>	
            </div>				
        </section>
        <!-- End Login Area -->	

        <section class="home-about-area section-gap"></section>
        <section class="home-about-area section-gap"></section>	

        <?php
        include 'footer.html';
        ?>

    </body>
</html>