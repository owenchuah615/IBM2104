<?php

//connect database
$db = mysqli_connect('localhost', 'root', '');
mysqli_select_db($db, 'vroomvroom');

//query to delete the selected row
$delete = "DELETE FROM ordering WHERE ID = {$_GET['id']}";

//if query is successfully executed display success output message
if(mysqli_query($db , $delete))
{
    echo "<script>alert('The order had been successfully deleted.')</script>";
    echo "<meta http-equiv='refresh' content='0;url=cart.php'>";
}
else
{
    echo "<script>alert('Failed to delete order.')</script>";
    echo "<meta http-equiv='refresh' content='0;url=cart.php'>";
}

mysqli_close($db);
?>        