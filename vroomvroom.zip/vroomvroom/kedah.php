<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Vroom Vroom</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/jquery-ui.css">			
			<link rel="stylesheet" href="css/main.css">
            <link rel="stylesheet" href="css/table1.css">
   
		</head>
		<body>	
			 <?php
            
            include 'header.php';
            
            ?>
			  
			<!-- start banner Area -->
			<section class="banner-area relative about-banner" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Destination			
							</h1>	
							<p class="text-white link-nav"><a href="home.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="destination.php">Destination</a></p>
                            </div>
						</div>	
                </div>
			</section>
			<!-- End banner Area -->	
            
            <!--content-->
            <div class="whole-wrap">
				<div class="container">
					<div class="section-top-border">
                        <h1 align=center>ALor Setar , Kedah</h1>
                    </div>
                        <section class="kedah">
                        <div class="section-top-border">
						<h3 class="mb-30">Paddy Museum</h3>
						<div class="row">
							<div class="col-md-3">
								<img src="img/destination/kedah1.jpg" alt="" class="img-fluid">
							</div>
							<div class="col-md-9 mt-sm-20 left-align-p">
								<p>Kedah is the ‘Rice Bowl of Malaysia’.

Paddy fields stretch towards the horizon in all directions. Rice holds a special place in the heart of the state.

A trip to the Kedah Paddy Museum is among the best things to do in Alor Setar for anyone with more than 24 hours in the city. The building itself looks like an overflowing rice basket.

The three-storied museum covers everything about rice and its cultivation in Kedah. The lower floor displays machinery and presents the cultural role of rice. The middle level provides context for its sale and distribution.

But, Kedah Paddy Museum’s highlight is the vast mural spanning the third floor’s circular wall. The image depicts a scene from rural Kedah: Farmer performing their day-to-day duties and tending to their crop.</p>
							</div>
						</div>
                            </div>
                        
                        <div class="section-top-border">
                            <h3 class="mb-30">Alor Setar Tower</h3>
						<div class="row">
							<div class="col-md-3">
                                
								<img src="img/destination/kedah2.jpg" alt="" class="img-fluid">
							</div>
							<div class="col-md-9 mt-sm-20 left-align-p">
								<p>Almost every image of Kedah’s capital includes either Zahir Mosque or Alor Setar Tower. Looking almost like a giant spaceship from a 1950s sci-fi movie, it dominates the skyline.

The telecommunication tower stands at 165.5 meters (543 feet) and acts as the city’s centerpiece. A viewing platform provides panoramic views of Alor Setar and its surrounding paddy fields.

Or head to the rooftop’s revolving restaurant for a romantic evening in one of the city’s most exclusive spots.

Because of its size, getting a photo of Alor Setar Tower is a challenge. Crazy Tourist recommends standing on Darul Aman Highway near Zahir Mosque to capture its monumental scale.</p>
							</div>
						</div>
                            </div>
        
                        <div class="section-top-border">
                        <h3 class="mb-30">Kedah State Art Gallery</h3>
						<div class="row">
							<div class="col-md-3">
								<img src="img/destination/kedah3.jpg" alt="" class="img-fluid">
							</div>
							<div class="col-md-9 mt-sm-20 left-align-p">
								<p>The former High Court on the southern part of Dataran Alor Setar houses Kedah State Art Gallery.

Local Kedah-born artisans contribute to most exhibits which include handicraft, paintings and installations. Others use black and white photographs to tell the story of rural Kedah.

The structure itself is the oldest government building in Alor Setar.

Take time to appreciate the Neo-classical exterior before strolling through its multiple galleries.

Visitors spend between 30 minutes to one hour inside the Kedah State Art Gallery. Most appreciate the respite from the stifling heat inside their air-conditioned rooms.</p>
							</div>
						</div>
                            </div>
                        </section>
					</div>
                </div>
            <!--content end-->
<?php
            
            include 'footer.html';
            
            ?>

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
 			<script src="js/jquery-ui.js"></script>								
			<script src="js/jquery.nice-select.min.js"></script>							
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>